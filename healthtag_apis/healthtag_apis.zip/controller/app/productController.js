const { Sequelize } = require("sequelize");
const { dataNotFound } = require("../../helper/helperFunction");
const {
  Product,
  Category,
  ProductImages,
  CategoryQuestion,
  Cart,
  CartItem,
  Order,
  OrderItem,
  UserReview,
  QuestionnairesOption,
  User,
  Blog,
} = require("../../model");
const joi = require("joi");

exports.getAllCategories = async (req, res, next) => {
  try {
    const categories = await Category.findAll({ where: { status: "active" } });
    return res.status(200).json({
      status: true,
      message: "All Categories",
      data: categories,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getCategoryDetails = async (req, res, next) => {
  try {
    const categories = await Category.findOne({ where: { id: req.params.categoryId, status: "active" } });
    return res.status(200).json({
      status: true,
      message: " Category details",
      data: categories,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getAllProducts = async (req, res, next) => {
  try {
    let products;
    if (req.query.categoryId) {
      products = await Product.findAll({
        where: { categoryId: req.query.categoryId, status: "active" },
        include: [
          { model: ProductImages, attributes: ["id", "image", "productId"] },
          { model: Category, attributes: ["id", "category"], where: { status: "active" } },
        ],
      });
    } else {
      products = await Product.findAll({
        where: { status: "active" },
        include: [
          { model: ProductImages, attributes: ["id", "image", "productId"] },
          { model: Category, attributes: ["id", "category"], where: { status: "active" } },
        ],
      });
    }

    return res.status(200).json({
      status: true,
      message: "All products",
      data: products,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getProductDetails = async (req, res, next) => {
  try {
    const product = await Product.findOne({
      where: { id: req.params.productId },
      include: [
        { model: ProductImages, attributes: ["id", "image", "productId"] },
        { model: Category, attributes: ["id", "category"] },
        {
          model: UserReview,
          include: [{ model: User, attributes: ["id", "first_name", "last_name", "profile_image", "email"] }],
        },
      ],
    });
    let product_rating = calculateAverageRating(product.user_reviews);
    product.dataValues.product_rating = product_rating;
    product.dataValues.total_reviews = (product.user_reviews && product.user_reviews.length) || 0;

    return res.status(200).json({
      status: true,
      message: "prduct detail",
      data: product,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getCategoryQuestion = async (req, res, next) => {
  try {
    const questions = await CategoryQuestion.findAll({
      where: { categoryId: req.params.categoryId },
      include: [{ model: QuestionnairesOption }],
    });
    if (questions && questions.length === 0) {
      return res.status(400).json({
        status: false,
        message: "No Question Found",
      });
    }
    return res.status(200).json({
      status: true,
      message: "Category Question",
      data: questions,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.addToCart = async (req, res, next) => {
  try {
    const { productId } = req.body;
    const product = await Product.findOne({ where: { id: productId } });
    dataNotFound(product, "product not found", 404);
    console.log("req userid", req.userId);
    const cart = await Cart.findOne({ where: { userId: req.userId } });
    if (cart) {
      const cartProduct = await CartItem.findOne({ where: { cartId: cart.id, productId: productId } });

      if (cartProduct) {
        const error = new Error("Product already in your cart");
        error.statusCode = 406;
        throw error;
      }
      cart.total = cart.total + product.price;
      await cart.save();
      await cart.reload();
      await CartItem.create({
        quantity: 1,
        cartId: cart.id,
        productId: productId,
      });
    } else {
      const cart = await Cart.create({
        userId: req.userId,
        total: product.price,
      });
      await CartItem.create({
        quantity: 1,
        cartId: cart.id,
        productId: productId,
      });
    }
    return res.status(200).json({
      status: true,
      message: "Item added to cart",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.changeProductQuantity = async (req, res, next) => {
  try {
    const { cartId, productId, quantity } = req.body;
    const cart = await Cart.findOne({ where: { id: cartId } });
    const cartItem = await CartItem.findOne({ where: { cartId: cartId, productId: productId } });
    if (quantity == 0) {
      await cartItem.destroy();
    } else {
      cartItem.quantity = quantity;
      await cartItem.save();
      await cartItem.reload();
    }

    let total = 0;
    let i = 0;
    const cartItems = await CartItem.findAll({ where: { cartId: cartId } });
    while (i < cartItems.length) {
      let item = cartItems[i];
      let product = await Product.findOne({ where: { id: item.productId } });
      total = total + product.price * item.quantity;
      i++;
    }
    cart.total = total;
    await cart.save();
    await cart.reload();
    if (cartItems.length == 0) {
      cart.destroy();
    }
    return res.status(200).json({
      status: true,
      message: "Item quantity changed",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.deleteItemFromCart = async (req, res, next) => {
  try {
    const { cartId, productId } = req.body;
    const cart = await Cart.findOne({ where: { id: cartId } });
    const cartItem = await CartItem.findOne({ where: { cartId: cartId, productId: productId } });

    await cartItem.destroy();

    let total = 0;
    let i = 0;
    const cartItems = await CartItem.findAll({ where: { cartId: cartId } });
    while (i < cartItems.length) {
      let item = cartItems[i];
      let product = await Product.findOne({ where: { id: item.productId } });
      total = total + product.price * item.quantity;
      i++;
    }
    cart.total = total;
    await cart.save();
    await cart.reload();
    if (cartItems.length == 0) {
      cart.destroy();
    }
    return res.status(200).json({
      status: true,
      message: "Item removed from cart",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getMyCart = async (req, res, next) => {
  try {
    const cart = await Cart.findOne({
      where: { userId: req.userId },
      include: [
        {
          model: CartItem,
          attributes: ["id", "quantity", "cartId", "productId"],
          include: [
            {
              model: Product,
              attributes: ["id", "name", "price", "status"],
              include: [{ model: ProductImages, attributes: ["id", "image"] }],
            },
          ],
        },
      ],
    });
    if (cart) {
      return res.status(200).json({
        status: true,
        message: "User Cart",
        data: cart,
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "Cart is empty",
      });
    }
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.checkoutCartItem = async (req, res, next) => {
  try {
    const { cartId, addressId, cardId } = req.body;
    const cart = await Cart.findOne({ where: { id: cartId, userId: req.userId } });
    dataNotFound(cart, "cart not found", 404);
    const cartItems = await CartItem.findAll({
      where: { cartId: cartId },
      include: [
        {
          model: Product,
          attributes: ["id", "name", "price", "status"],
          include: [{ model: ProductImages, attributes: ["id", "image"] }],
        },
      ],
    });
    if (cartItems.length == 0) {
      const error = new Error("Please add products in your cart");
      error.statusCode = 404;
      throw error;
    }
    const order = await Order.create({
      total: cart.total,
      status: "pending",
      payment_id: Math.floor(100000 + Math.random() * 900000),
      mode: "card",
      addressId: addressId,
      cardId: cardId,
      userId: req.userId,
    });
    for (let i = 0; i < cartItems.length; i++) {
      await OrderItem.create({
        orderId: order.id,
        quantity: cartItems[i].quantity,
        productId: cartItems[i].productId,
        item_price: cartItems[i].product.price,
      });
    }

    console.log("checksum cart itesms");
    await CartItem.destroy({ where: { cartId: cartId } });
    await cart.destroy();
    return res.status(200).json({
      status: true,
      message: "Order Placed Successfully",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getAllMyOrders = async (req, res, next) => {
  try {
    const orders = await Order.findAll({
      where: { userId: req.userId },
      order: [["createdAt", "DESC"]],
      include: [
        {
          model: OrderItem,
          attributes: ["id", "quantity", "item_price", "orderId", "productId"],
          include: [
            {
              model: Product,
              attributes: ["id", "name", "status"],
              include: [{ model: ProductImages, attributes: ["id", "image"] }],
            },
          ],
        },
      ],
    });
    if (orders) {
      return res.status(200).json({
        status: true,
        message: "User Orders",
        data: orders,
      });
    } else {
      return res.status(200).json({
        status: true,
        message: "No Order Found",
      });
    }
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.buyNowProduct = async (req, res, next) => {
  try {
    const { productId, addressId, cardId } = req.body;
    const product = await Product.findOne({ where: { id: productId } });
    dataNotFound(product, "Data not found", 404);
    const order = await Order.create({
      total: product.price,
      status: "pending",
      payment_id: Math.floor(100000 + Math.random() * 900000),
      mode: "card",
      userId: req.userId,
      addressId: addressId,
      cardId: cardId,
    });
    await OrderItem.create({
      orderId: order.id,
      quantity: 1,
      productId: product.id,
      item_price: product.price,
    });
    return res.status(200).json({
      status: true,
      message: "Order Placed Successfully",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.dashboardData = async (req, res, next) => {
  try {
    const products = await Product.findAll({
      order: Sequelize.literal("rand()"),
      limit: 5,
      include: [
        { model: ProductImages, attributes: ["id", "image", "productId"] },
        { model: Category, attributes: ["id", "category"], where: { status: "active" } },
      ],
    });

    const blogs = await Blog.findAll({
      order: Sequelize.literal("rand()"),
      limit: 5,
    });

    return res.status(200).json({
      status: true,
      message: "Dashboard data",
      data: { products, blogs },
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getRecomendedProducts = async (req, res, next) => {
  try {
    const products = await Product.findAll({
      order: Sequelize.literal("rand()"),
      limit: 5,
      include: [
        { model: ProductImages, attributes: ["id", "image", "productId"] },
        { model: Category, attributes: ["id", "category"], where: { status: "active" } },
      ],
    });

    return res.status(200).json({
      status: true,
      message: "Your recommended products",
      data: products,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.AddUserReview = async (req, res, next) => {
  try {
    const schema = joi.object({
      productId: joi.number().required(),
      rating: joi.string().valid("1", "2", "3", "4", "5").required(),
      review: joi.string().required(),
    });
    await schema.validateAsync(req.body);
    const checkReview = await UserReview.findOne({ productId: req.body.productId, userId: req.userId });
    if (checkReview) {
      const error = new Error("You have already given your review on this product");
      error.statusCode = 401;
      throw error;
    }
    const review = await UserReview.create({
      productId: req.body.productId,
      userId: req.userId,
      rating: req.body.rating,
      review: req.body.review,
    });
    return res.status(200).json({
      status: true,
      message: "Thanks for you review",
      data: review,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

function calculateAverageRating(ratings) {
  let sum = 0;
  for (let i = 0; i < ratings.length; i++) {
    sum += parseInt(ratings[i].rating);
  }
  return sum / ratings.length;
}
