const User = require("../../model/user");
const { uploadFile, removeFile } = require("../../helper/File");
const joi = require("joi");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const { dataNotFound } = require("../../helper/helperFunction");
const {
  UserAddress,
  ProviderProfile,
  MyCustomers,
  ProviderSpecialities,
  Category,
  TenantProfile,
  UserPayment,
  QuestionnairesResult,
  QuestionnairesOption,
  CategoryQuestion,
} = require("../../model");
const { Op, where } = require("sequelize");

exports.editUserProfile = async (req, res, next) => {
  const schema = joi.object({
    first_name: joi.string().optional(),
    last_name: joi.string().optional(),
    email: joi.string().optional(),
    profile_image: joi.string().optional(),
    phone_no: joi.string().optional(),
    gender: joi.string().allow("male", "female", "other").optional(),
    height1: joi.string().optional(),
    height2: joi.string().optional(),
    height_msr: joi.string().optional(),
    weight: joi.string().optional(),
    weight_msr: joi.string().optional(),
    language: joi.string().optional(),
  });

  let uploadfile;
  try {
    const { body, file } = await uploadFile(req, "images/users");
    await schema.validateAsync(req.body);
    uploadfile = file;
    console.log(req.body);
    const user = await User.findOne({ where: { id: req.userId } });
    if (user.profile_image && file.path) {
      removeFile(user.profile_image);
    }
    if (file) {
      user.profile_image = file.path;
    }
    for (let key in body) {
      user[key] = body[key];
    }
    user.save();
    user.reload();
    res.status(200).json({
      status: true,
      data: user,
      message: "Profile Updated Successfully",
    });
  } catch (err) {
    if (uploadfile && uploadFile.path) {
      removeFile(uploadfile.path);
    }
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.editUserProfileById = async (req, res, next) => {
  const schema = joi.object({
    first_name: joi.string().optional(),
    last_name: joi.string().optional(),
    email: joi.string().optional(),
    profile_image: joi.string().optional(),
    age: joi.number().required(),
    phone_no: joi.string().required(),
    gender: joi.string().allow("male", "female", "other").required(),
    height1: joi.string().optional(),
    height2: joi.string().optional(),
    height_msr: joi.string().optional(),
    weight: joi.string().optional(),
    weight_msr: joi.string().optional(),
    language: joi.string().optional(),
  });

  let uploadfile;
  try {
    const { body, file } = await uploadFile(req, "images/users");
    await schema.validateAsync(req.body);
    uploadfile = file;
    console.log(req.body);
    const user = await User.findOne({ where: { id: req.params.userId } });
    if (user.profile_image && file.path) {
      removeFile(user.profile_image);
    }
    if (file) {
      user.profile_image = file.path;
    }
    for (let key in body) {
      user[key] = body[key];
    }
    user.save();
    user.reload();
    res.status(200).json({
      status: true,
      data: user,
      message: "Signup Successfully",
    });
  } catch (err) {
    if (uploadfile && uploadFile.path) {
      removeFile(uploadfile.path);
    }
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.changeUserPassword = async (req, res, next) => {
  const schema = joi.object({
    oldPassword: joi.string().required(),
    newPassword: joi.string().required(),
  });
  try {
    await schema.validateAsync(req.body);
    const user = await User.findOne({ where: { id: req.userId } });
    let comparePassword = await bcrypt.compare(req.body.oldPassword, user.password);
    if (!comparePassword) {
      const error = new Error("Old Password is wrong");
      error.statusCode = 401;
      throw error;
    }
    const hashedPassword = await bcrypt.hash(req.body.newPassword, 12);
    user.password = hashedPassword;
    user.save();
    res.status(200).json({
      status: true,
      message: "Password Changed Successfully",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getUserProfile = async (req, res, next) => {
  try {
    const user = await User.findOne({ where: { id: req.userId } });
    dataNotFound(user, "User Not Found", 401);
    res.status(200).json({
      status: true,
      message: "User Profile",
      data: user,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.addUserAddress = async (req, res, next) => {
  const schema = joi.object({
    address: joi.string().required(),
    city: joi.string().required(),
    state: joi.string().required(),
    zipcode: joi.string().required(),
    latitude: joi.string().optional(),
    longitude: joi.string().optional(),
    default_address: joi.boolean().optional(),
    address_type: joi.string().optional(),
  });
  try {
    await schema.validateAsync(req.body);
    const create = new Object();
    create.address = req.body.address;
    create.city = req.body.city;
    create.state = req.body.state;
    create.zipcode = req.body.zipcode;
    create.default_address = req.body.default_address;
    create.address_type = req.body.address_type;
    create.userId = req.userId;
    create.latitude = req.body.latitude || null;
    create.longitude = req.body.longitude || null;
    const address = await UserAddress.create(create);
    res.status(200).json({
      status: true,
      message: "User address added",
      data: address,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.editUserAddress = async (req, res, next) => {
  const schema = joi.object({
    address: joi.string().required(),
    city: joi.string().required(),
    state: joi.string().required(),
    zipcode: joi.string().required(),
    latitude: joi.string().optional(),
    longitude: joi.string().optional(),
    default_address: joi.boolean().optional(),
    address_type: joi.string().optional(),
    addressId: joi.number().required(),
  });
  try {
    await schema.validateAsync(req.body);
    const address = await UserAddress.findOne({ where: { id: req.body.addressId, userId: req.userId } });
    dataNotFound(address, "data not found", 401);
    address.address = req.body.address;
    address.city = req.body.city;
    address.state = req.body.state;
    address.zipcode = req.body.zipcode;
    address.default_address = req.body.default_address;
    address.address_type = req.body.address_type;
    address.latitude = req.body.latitude || null;
    address.longitude = req.body.longitude || null;
    await address.save();
    await address.reload();
    res.status(200).json({
      status: true,
      message: "User address Edited",
      data: address,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.deleteMyAddress = async (req, res, next) => {
  try {
    const address = await UserAddress.destroy({ where: { id: req.params.addressId, userId: req.userId } });
    res.status(200).json({
      status: true,
      message: "User address deletd",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getMyAddresses = async (req, res, next) => {
  try {
    const address = await UserAddress.findAll({ where: { userId: req.userId } });
    dataNotFound(address, "data Not Found", 401);
    res.status(200).json({
      status: true,
      message: "User address",
      data: address,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.submitCategoryQuestions = async (req, res, next) => {
  const TODAY_START = new Date().setHours(0, 0, 0, 0);
  const NOW = new Date();
  try {
    const { questionId, optionId, categoryId } = req.body;
    const findData = await QuestionnairesResult.findOne({
      where: {
        questionId: questionId,
        userId: req.userId,
        optionId: optionId,
        categoryId: categoryId,
        createdAt: {
          [Op.gt]: TODAY_START,
          [Op.lt]: NOW,
        },
      },
    });
    if (findData) {
      const error = new Error("You have already submitted answer for this question today");
      error.statusCode = 401;
      throw error;
    }
    let attemptNo = 1;
    const getAttempt = await QuestionnairesResult.findOne({
      where: {
        questionId: questionId,
        userId: req.userId,
        optionId: optionId,
        categoryId: categoryId,
      },
    });
    if (getAttempt) {
      attemptNo = attemptNo + 1;
    }
    const getQuestion = await CategoryQuestion.findOne({ where: { categoryId: categoryId, id: questionId } });
    if (!getQuestion) {
      const error = new Error("No question found for this category");
      error.statusCode = 401;
      throw error;
    }
    const catAnswer = await QuestionnairesResult.create({
      questionId: questionId,
      optionId: optionId,
      userId: req.userId,
      attemptNo: attemptNo,
      categoryId: categoryId,
    });
    return res.status(200).json({
      status: true,
      message: "Answer submitted",
      data: catAnswer,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getQuestionariesResult = async (req, res, next) => {
  try {
    const getResult = await QuestionnairesResult.findAll({
      where: { categoryId: req.params.categoryId, userId: req.userId },
      include: [{ model: QuestionnairesOption }],
    });
    let score = 0;
    let i = 0;
    while (i < getResult.length) {
      let item = getResult[i];
      score = item.questionnaires_option.score + score;
      i++;
    }

    let category = await Category.findOne({ where: { id: req.params.categoryId } });
    let resultType = "";
    if (score <= category.red_zone) {
      resultType = "red";
    } else if (score <= category.yellow_zone && score > category.red_zone) {
      resultType = "yellow";
    } else if (score > category.yellow_zone || score == category.green_zone) {
      resultType = "green";
    }

    return res.status(200).json({
      status: true,
      message: "Your Result",
      data: { score, resultType },
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getAllProviders = async (req, res, next) => {
  try {
    let where;
    if (req.query.name) {
      where = {
        userType: "health_provider",
        status: "active",
        [Op.or]: [{ first_name: { [Op.like]: "%" + req.query.name + "%" } }],
      };
    } else {
      where = {
        userType: "health_provider",
        status: "active",
      };
    }
    const getProviders = await User.findAll({
      attributes: ["id", "first_name", "last_name", "email", "phone_no", "userType", "profile_image"],
      where: where,
      include: [
        {
          model: ProviderProfile,
          attributes: [
            "id",
            "business_name",

            "incorporation_year",
            "certification_number",
            "contact_person",
            "userId",
            "tenantId",
          ],
        },
        {
          model: ProviderSpecialities,
          attributes: ["id", "userId", "categoryId"],
          include: [
            { model: Category, where: { status: "active" }, attributes: ["id", "category", "short_desc", "image"] },
          ],
        },
      ],
    });
    const myProviders = await MyCustomers.findAll({
      where: { customerId: req.userId },
    });
    let ids = new Set(myProviders.map(({ providerId }) => providerId));
    let allProviders = getProviders.filter(({ id }) => !ids.has(id));

    return res.status(200).json({
      status: true,
      message: "All Providers List",
      data: allProviders,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.connectToProviders = async (req, res, next) => {
  try {
    const checkUser = await MyCustomers.findOne({ where: { customerId: req.userId, providerId: req.body.providerId } });
    if (checkUser) {
      let error = new Error("You are already connected to this provider");
      error.statusCode = 401;
      throw error;
    }
    let provider = await ProviderProfile.findOne({ where: { userId: req.body.providerId } });
    const customers = await MyCustomers.findAll({ where: { tenantId: provider.tenantId } });
    const totalUsers = await TenantProfile.findOne({ where: { userId: provider.tenantId } });

    if (customers.length + 1 > totalUsers.users) {
      const error = new Error("This Business customer limit is full, You can not connect to this business");
      error.statusCode = 401;
      throw error;
    }

    await MyCustomers.create({
      customerId: req.userId,
      providerId: req.body.providerId,
      tenantId: provider.tenantId,
    });
    return res.status(200).json({
      status: true,
      message: "Connected to provider successfully",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getProviderProfileENC = async (req, res, next) => {
  try {
    let encProvider = JSON.parse(decryptData(req.body.payload));
    console.log("encProvider", encProvider);
    let provider = await User.findOne({
      attributes: ["id", "first_name", "last_name", "email", "phone_no", "userType", "profile_image"],
      where: { id: encProvider.providerId },
      include: [
        {
          model: ProviderProfile,
          attributes: [
            "id",
            "business_name",
            "qr_code",
            "incorporation_year",
            "certification_number",
            "contact_person",
            "userId",
            "tenantId",
          ],
        },
        {
          model: ProviderSpecialities,
          attributes: ["id", "userId", "categoryId"],
          include: [
            { model: Category, where: { status: "active" }, attributes: ["id", "category", "short_desc", "image"] },
          ],
        },
      ],
    });
    return res.status(200).json({
      status: true,
      message: "Provider Profile",
      data: provider,
    });
  } catch (err) {
    console.log("errr--", err);
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.addUserPaymentMethod = async (req, res, next) => {
  try {
    const schema = joi.object({
      name_on_card: joi.string().required(),
      card_no: joi.string().required(),
      month: joi.string().required(),
      year: joi.string().required(),
      cvv: joi.string().required(),
    });
    await schema.validateAsync(req.body);
    const payment = await UserPayment.create({
      name_on_card: req.body.name_on_card,
      card_no: req.body.card_no,
      month: req.body.month,
      year: req.body.year,
      cvv: req.body.cvv,
      userId: req.userId,
    });
    return res.status(200).json({
      status: true,
      message: "Payment method added",
      data: payment,
    });
  } catch (err) {
    console.log("errr--", err);
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.removePaymentMethod = async (req, res, next) => {
  try {
    const payment = await UserPayment.destroy({ where: { id: req.params.paymentId, userId: req.userId } });
    return res.status(200).json({
      status: true,
      message: "Payment method removed",
    });
  } catch (err) {
    console.log("errr--", err);
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getMyPayments = async (req, res, next) => {
  try {
    const payment = await UserPayment.findAll({ where: { userId: req.userId } });
    return res.status(200).json({
      status: true,
      message: "Payment methods",
      data: payment,
    });
  } catch (err) {
    console.log("errr--", err);
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

const decryptData = (encrypted) => {
  const algorithm = "aes-256-cbc";
  const secret = "HEALTHTAGQRCODEKEY";

  const key = crypto.createHash("sha256").update(String(secret)).digest("base64").substring(0, 32);
  // const iv = crypto.randomBytes(16);
  console.log("encrypted.iv", encrypted.iv);
  let iv = Buffer.from(encrypted.iv, "hex");
  let encryptedText = Buffer.from(encrypted.encryptedData, "hex");
  let decipher = crypto.createDecipheriv(algorithm, Buffer.from(key), iv);
  let decrypted = decipher.update(encryptedText);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
};
