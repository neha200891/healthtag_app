const User = require("../../model/user");
const { dataNotFound } = require("../../helper/helperFunction");
const { uploadFile, removeFile } = require("../../helper/File");
const AdminPassword = require("../../model/adminPassword");
const ejs = require("ejs");
const path = require("path");
const mailer = require("../../helper/mailHelper");
const config = require("config");
const UserOtp = require("../../model/userOtp");
const {
  TenantProfile,
  ProviderProfile,
  MyCustomers,
  ProviderSpecialities,
  Category,
  Order,
  OrderItem,
  Product,
  ProductImages,
  UserAddress,
  UserPayment,
} = require("../../model");
const { Op } = require("sequelize");
exports.getAllUsers = async (req, res, next) => {
  try {
    let users = await User.findAll({
      where: { [Op.or]: [{ userType: "user" }, { userType: "health_provider" }] },
      order: [["createdAt", "DESC"]],
    });
    res.status(200).json({
      status: true,
      message: "Users Found",
      data: users,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getUserProfile = async (req, res, next) => {
  try {
    let business_profile;
    let user = await User.findOne({
      where: { id: req.params.id },
      include: {
        model: AdminPassword,
      },
    });
    if (user.userType === "tenant") {
      let tenant = await TenantProfile.findOne({
        where: { userId: user.id },
      });
      user.dataValues.business_profile = tenant;
    } else if (user.userType === "health_provider") {
      let health_provider = await ProviderProfile.findOne({
        where: { userId: user.id },
        include: [
          {
            model: User,
            as: "tenant",
            attributes: ["id"],
            include: [{ model: TenantProfile, attributes: ["id", "business_name"] }],
          },
        ],
      });
      let specialities = await ProviderSpecialities.findAll({
        where: { userId: user.id },
        include: [{ model: Category, attributes: ["id", "category"] }],
      });
      let customers = await MyCustomers.findAll({
        where: { providerId: user.id },
        include: [{ model: User, attributes: ["first_name", "last_name", "email", "id"], as: "customer" }],
      });
      user.dataValues.customers = customers;
      user.dataValues.business_profile = health_provider;
      user.dataValues.specialities = specialities;
    } else {
      let customer = await MyCustomers.findOne({
        where: { customerId: user.id },
        include: [
          {
            model: User,
            as: "provider",
            attributes: ["id"],
            include: [{ model: ProviderProfile, attributes: ["business_name"] }],
          },
          {
            model: User,
            as: "Tenant",
            attributes: ["id"],
            include: [{ model: TenantProfile, attributes: ["business_name"] }],
          },
        ],
      });
      user.dataValues.customer = customer;
    }
    dataNotFound(user, "User Not Found", 401);
    res.status(200).json({
      status: true,
      message: "User Found",
      data: user,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.editUserProfileAdmin = async (req, res, next) => {
  let uploadfile;
  try {
    const { body, file } = await uploadFile(req, "images/users");
    uploadfile = file;
    const user = await User.findOne({ where: { id: req.params.id } });
    if (user.profile_image && file.path) {
      removeFile(user.profile_image);
    }
    if (file) {
      user.profile_image = file.path;
    }
    for (let key in body) {
      user[key] = body[key];
    }
    user.save();
    user.reload();
    res.status(200).json({
      status: true,
      message: "Profile Updated Successfully",
    });
  } catch (err) {
    removeFile(uploadfile.path);
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.changeUserStatus = async (req, res, next) => {
  const { userId, status } = req.body;
  try {
    let user = await User.findOne({ where: { id: userId } });
    dataNotFound(user, "User Not Found", 401);
    let message;
    let emailMessage = "";
    if (status == "blocked") {
      message = "User Blocked Successfully";
      emailMessage = `We have to inform you that your account has been blocked by healthtag admin.
            If You have any questions please contact us at info@healthtag.com`;
    } else if (status == "active") {
      message = "User Actived Successfully";
      emailMessage = `Congratulation! Your account is verified and actived by admin.
            You can now login to your account.
            `;
    }

    user.status = status;
    user.save();
    user.reload();
    const mailData = await ejs.renderFile(path.join(__dirname, "../../view/accountVerification.ejs"), {
      name: user.fullname,
      message: emailMessage,
    });
    await mailer.sendEmail(user.email, config.get("App.email"), "Health Tag ACCOUNT STATUS", mailData);
    res.status(200).json({
      status: true,
      message: message,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.latestCreatedUser = async (req, res, next) => {
  try {
    let users = await User.findAll({
      order: [["createdAt", "DESC"]],
      limit: 1,
    });

    return res.status(200).json({
      status: true,
      message: "Latest Created User",
      data: users,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.lastLoggedInUsersList = async (req, res, next) => {
  try {
    let users = await User.findAll({
      order: [["updatedAt", "DESC"]],
      where: { userType: "user" },
      limit: 3,
    });

    res.status(200).json({
      status: true,
      data: users,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.deleteUser = async (req, res, next) => {
  try {
    let user = await User.findOne({ where: { id: req.params.id } });
    dataNotFound(user, "User Not Found", 401);
    if (user.profile_image) {
      removeFile(user.profile_image);
    }
    await AdminPassword.destroy({ where: { userId: req.params.id } });

    await UserOtp.destroy({ where: { userId: req.params.id } });
    user.destroy();
    res.status(200).json({
      status: true,
      message: "User Deleted Successfully",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getAllTenants = async (req, res, next) => {
  try {
    const tenant = await User.findAll({ where: { userType: "tenant" }, include: [{ model: TenantProfile }] });
    return res.status(200).json({
      status: true,
      message: "All Tanents",
      data: tenant,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getAllTenantProviders = async (req, res, next) => {
  try {
    const tenantProviders = await ProviderProfile.findAll({
      where: { tenantId: req.params.tenantId },
      include: [{ model: User }],
    });
    return res.status(200).json({
      status: true,
      message: "All Tanents Providers",
      data: tenantProviders,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getAllHealthProviders = async (req, res, next) => {
  try {
    const tenant = await User.findAll({
      where: { userType: "health_provider" },
      include: [{ model: ProviderProfile, where: { tenantId: req.userId } }],
    });
    return res.status(200).json({
      status: true,
      message: "All Tanents",
      data: tenant,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getAllTenantCustomers = async (req, res, next) => {
  try {
    const tenantUser = await User.findAll({
      where: { userType: "health_provider" },
      attributes: ["id"],
      include: [
        { model: ProviderProfile, attributes: ["userId", "id", "business_name"], where: { tenantId: req.userId } },
        {
          model: MyCustomers,
          as: "provider",
          include: [{ model: User, as: "customer" }],
        },
      ],
    });
    const providerCustomers = await MyCustomers.findAll({
      include: [
        { model: User, as: "customer" },
        {
          model: User,
          as: "provider",
          attributes: ["id"],
          include: [
            { model: ProviderProfile, attributes: ["userId", "id", "business_name"], where: { tenantId: req.userId } },
          ],
        },
      ],
    });
    return res.status(200).json({
      status: true,
      message: "All Tanents",
      data: providerCustomers,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.editCustomerDetails = async (req, res, next) => {
  try {
    let myCustomer = await MyCustomers.findOne({ where: { customerId: req.body.customerId } });
    if (myCustomer) {
      myCustomer.tenantId = req.body.tenantId;
      myCustomer.providerId = req.body.providerId;
      await myCustomer.save();
      await myCustomer.reload();
    } else {
      myCustomer = await MyCustomers.create({
        customerId: req.body.customerId,
        tenantId: req.body.tenantId,
        providerId: req.body.providerId,
      });
    }

    return res.status(200).json({
      status: true,
      message: "Customer Edited ",
      data: myCustomer,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.editHealthProviderProfile = async (req, res, next) => {
  try {
    let providerProfile = await ProviderProfile.findOne({ where: { userId: req.body.providerId } });
    for (let key in req.body) {
      providerProfile[key] = req.body[key];
    }
    await providerProfile.save();
    await providerProfile.reload();
    return res.status(200).json({
      status: true,
      message: "Health Provider Edited ",
      data: providerProfile,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.changeCustomerTanency = async (req, res, next) => {
  try {
    const customers = JSON.parse(req.body.customers);
    const providerId = req.body.providerId;
    const tenantId = req.body.tenantId;
    for (let i = 0; i < customers.length; i++) {
      await MyCustomers.update({ providerId: providerId }, { where: { customerId: customers[i], tenantId: tenantId } });
    }
    return res.status(200).json({
      status: true,
      message: "Customer update to new provider",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getAllOrders = async (req, res, next) => {
  try {
    const orders = await Order.findAll({
      order: [["createdAt", "DESC"]],
      include: [
        { model: OrderItem },
        { model: User, attributes: ["id", "first_name", "last_name", "profile_image", "email", "phone_no"] },
      ],
    });
    return res.status(200).json({
      status: true,
      message: "All Orders",
      data: orders,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.getProductDetails = async (req, res, next) => {
  try {
    const orders = await Order.findOne({
      where: { id: req.params.orderId },
      order: [["createdAt", "DESC"]],
      include: [
        { model: OrderItem, include: [{ model: Product, include: [{ model: ProductImages }] }] },
        { model: User },
        { model: UserAddress },
        { model: UserPayment },
      ],
    });
    return res.status(200).json({
      status: true,
      message: "All Orders",
      data: orders,
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};

exports.changeOrderStatus = async (req, res, next) => {
  try {
    const { orderId, expected_delivery_date, tracking_id, delivery_partner, tracking_url, status } = req.body;
    const obj = {
      ...(expected_delivery_date && { expected_delivery_date: expected_delivery_date }),
      ...(tracking_id && { tracking_id: tracking_id }),
      ...(delivery_partner && { delivery_partner: delivery_partner }),
      ...(tracking_url && { tracking_url: tracking_url }),
      status: status,
    };
    console.log("check update state", obj);
    const order = await Order.update(obj, { where: { id: orderId } });
    return res.status(200).json({
      status: true,
      message: "Order status updated",
    });
  } catch (err) {
    if (!err.statusCode) {
      err.statusCode = 500;
    }
    next(err);
  }
};
