// const { Sequelize, Model, DataTypes } = require("sequelize");
// const sequelize = require("../database/util");

// class UserCategoryQuestion extends Model {}

// UserCategoryQuestion.init(
//   {
//     answer: {
//       type: DataTypes.STRING,
//     },
//   },
//   {
//     sequelize,
//     modelName: "usercategoryquestion",
//   }
// );

// module.exports = UserCategoryQuestion;
