const { Sequelize, Model, DataTypes } = require("sequelize");
const sequelize = require("../database/util");

class Cart extends Model {}

Cart.init(
  {
    total: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
  },
  {
    sequelize,
    tableName: "cart",
  }
);

module.exports = Cart;
