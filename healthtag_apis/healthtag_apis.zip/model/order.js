const { Sequelize, Model, DataTypes } = require("sequelize");
const sequelize = require("../database/util");

class Order extends Model {}

Order.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
      unique: true,
    },
    status: {
      type: DataTypes.ENUM("pending", "dispatched", "completed", "cancelled"),
    },
    total: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    payment_id: {
      type: DataTypes.STRING,
    },
    mode: {
      type: DataTypes.ENUM("cash", "online", "card"),
    },
    expected_delivery_date: {
      type: DataTypes.STRING,
    },
    tracking_id: {
      type: DataTypes.STRING,
    },
    delivery_partner: {
      type: DataTypes.STRING,
    },
    tracking_url: {
      type: DataTypes.STRING,
    },
  },
  {
    sequelize,
    tableName: "order",
  }
);

module.exports = Order;
