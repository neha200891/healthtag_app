const { Sequelize, Model, DataTypes } = require("sequelize");
const sequelize = require("../database/util");

class CategoryQuestion extends Model {}

CategoryQuestion.init(
  {
    question: {
      type: DataTypes.STRING,
    },
  },
  {
    sequelize,
    modelName: "categoryquestion",
  }
);

module.exports = CategoryQuestion;
