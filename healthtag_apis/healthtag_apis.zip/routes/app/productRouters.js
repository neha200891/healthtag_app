const router = require("express").Router();
const productController = require("../../controller/app/productController");
const isAuth = require("../../middleware/isAuth");
router.get("/getCategories", productController.getAllCategories);
router.get("/getCategoriesDetails/:categoryId", productController.getCategoryDetails);
router.get("/getProducts", productController.getAllProducts);
router.get("/productDetail/:productId", productController.getProductDetails);
router.get("/categoryQuestion/:categoryId", productController.getCategoryQuestion);

router.post("/addToCart", isAuth, productController.addToCart);
router.post("/changeProductQuantity", isAuth, productController.changeProductQuantity);
router.post("/removeItemFromCart", isAuth, productController.deleteItemFromCart);
router.get("/getMyCart", isAuth, productController.getMyCart);

router.post("/checkoutCartItems", isAuth, productController.checkoutCartItem);

router.get("/getMyOrders", isAuth, productController.getAllMyOrders);

router.post("/buyNowProduct", isAuth, productController.buyNowProduct);

router.get("/getRecommendedProducts", isAuth, productController.getRecomendedProducts);
router.get("/dashboard", productController.dashboardData);

router.post("/postUserReview", isAuth, productController.AddUserReview);

module.exports = router;
