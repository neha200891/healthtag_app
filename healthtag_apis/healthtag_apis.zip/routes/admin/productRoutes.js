const router = require("express").Router();
const productController = require("../../controller/admin/productController");

router.post("/add-category", productController.addCategory);
router.get("/get-categories", productController.getAllCategories);
router.get("/change-category-status/:categoryId", productController.changeCategoryStatus);
router.get("/delete-category/:categoryId", productController.deleteCategory);

router.post("/add-product", productController.addProduct);
router.get("/get-products", productController.getAllProducts);
router.get("/change-product-status/:productId", productController.changeProductStatus);
router.get("/delete-product/:productId", productController.deleteProduct);
router.get("/delete-product-image/:imageId", productController.deleteProductImage);

router.post("/addCategoryQuestion", productController.addCategoryQuestion);
router.get("/getCategoryQuestion", productController.getAllCategoryQuestion);
router.get("/questionDetails/:questionId", productController.getCategoryQuestionDetails);

router.post("/editCategoryQuestion", productController.editQuestions);
router.post("/addEditQuestionOption", productController.addEditQuestionOption);

module.exports = router;
